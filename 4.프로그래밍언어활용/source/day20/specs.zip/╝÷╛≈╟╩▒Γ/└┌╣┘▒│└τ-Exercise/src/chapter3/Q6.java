package chapter3;

public class Q6 {

	public static void main(String[] args) {
		int num = 8;
		
		System.out.println(num += 10);
		System.out.println(num -= 10);
		System.out.println(num >>= 2);
	}
}
