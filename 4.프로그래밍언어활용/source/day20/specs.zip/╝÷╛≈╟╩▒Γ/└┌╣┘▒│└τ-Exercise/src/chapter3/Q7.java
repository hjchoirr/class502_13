package chapter3;

public class Q7 {

	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 20;
		
		int result = (num1 >= 10) ? num2 +10: num2 - 10;
		System.out.println(result);
	}
}
