package chapter12.q6;

public class Car {
	String name;
	
	public Car() {}
	public Car(String name ) {
		this.name = name;
	}
}


